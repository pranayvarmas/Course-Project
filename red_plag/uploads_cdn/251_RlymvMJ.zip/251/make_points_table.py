import sqlite3
conn = sqlite3.connect('ipl.db');
cursor = conn.cursor();
cursor1= conn.cursor();
cursor.execute("DROP TABLE IF EXISTS POINTS_TABLE")
cursor.execute("CREATE TABLE POINTS_TABLE AS SELECT * FROM TEAM")
cursor.execute("ALTER TABLE POINTS_TABLE ADD points INT")
cursor.execute("ALTER TABLE POINTS_TABLE ADD nrr real")
cursor.execute("UPDATE POINTS_TABLE SET points='0'")
cursor.execute("UPDATE POINTS_TABLE SET nrr='0'")
cursor.execute('SELECT * FROM MATCH')
cursor1.execute('SELECT * FROM POINTS_TABLE')
l=[]
x=[]
y=[]
z=[]
i=0
for row in cursor:
	l.append(row[10])
	x.append(row[14])
	y.append(int(row[2]))
	z.append(int(row[3]))
	if(row[12]=="runs"):
		cursor1.execute("UPDATE POINTS_TABLE SET points=points+2 WHERE team_id =:Id", {"Id": l[i]})
		if(int(row[2])!=int(l[i])):
			cursor1.execute("UPDATE POINTS_TABLE SET nrr=nrr-(:Id1)*1.0/20 WHERE team_id =:Id2", {"Id2":y[i] ,"Id1":x[i]})
			cursor1.execute("UPDATE POINTS_TABLE SET nrr=nrr+(:Id1)*1.0/20 WHERE team_id =:Id2", {"Id2": z[i],"Id1":x[i]})
		if(y[i]==int(l[i])):
			cursor1.execute("UPDATE POINTS_TABLE SET nrr=nrr+(:Id1)*1.0/20 WHERE team_id =:Id2", {"Id2": y[i],"Id1":x[i]})
			cursor1.execute("UPDATE POINTS_TABLE SET nrr=nrr-(:Id1)*1.0/20 WHERE team_id =:Id2", {"Id2":z[i] ,"Id1":x[i]})
	if(row[12]=="wickets"):
		cursor1.execute("UPDATE POINTS_TABLE SET points=points+2 WHERE team_id =:Id", {"Id": l[i]})
		if(y[i]!=int(l[i])):
			cursor1.execute("UPDATE POINTS_TABLE SET nrr=nrr-((:Id1))*1.0/10 WHERE team_id =:Id2", {"Id2":y[i] ,"Id1":x[i]})
			cursor1.execute("UPDATE POINTS_TABLE SET nrr=nrr+(:Id1)*1.0/10 WHERE team_id =:Id2", {"Id2": z[i],"Id1":x[i]})
		if(y[i]==int(l[i])):
			cursor1.execute("UPDATE POINTS_TABLE SET nrr=nrr+(:Id1)*1.0/10 WHERE team_id =:Id2", {"Id2": y[i],"Id1":x[i]})
			cursor1.execute("UPDATE POINTS_TABLE SET nrr=nrr-(:Id1)*1.0/10 WHERE team_id =:Id2", {"Id2":z[i] ,"Id1":x[i]})
	if(row[12]=='NA'):
		cursor1.execute("UPDATE POINTS_TABLE SET points=points+1 WHERE team_id =:Id", {"Id": y[i]})
		cursor1.execute("UPDATE POINTS_TABLE SET points=points+1 WHERE team_id =:Id", {"Id": z[i]})
	if(row[12]=='Tie'):
		cursor1.execute("UPDATE POINTS_TABLE SET points=points+1 WHERE team_id =:Id", {"Id": y[i]})
		cursor1.execute("UPDATE POINTS_TABLE SET points=points+1 WHERE team_id =:Id", {"Id": z[i]})
	i=i+1
cursor1.execute('SELECT * FROM POINTS_TABLE order by points desc, nrr desc')
i=1;
for r in cursor1:
	print("%s,%s,%s,%s" %(r[0],r[1],r[2],r[3]))
	i=i+1
conn.commit()
conn.close()