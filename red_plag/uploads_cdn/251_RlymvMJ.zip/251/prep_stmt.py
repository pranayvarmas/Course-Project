import sys
import sqlite3
conn = sqlite3.connect('ipl.db');
cursor = conn.cursor();
l=sys.argv
if(l[1]=='1'):
	statement="INSERT INTO TEAM VALUES(?,?)"
if(l[1]=='2'):
	statement="INSERT INTO PLAYER VALUES (?,?,?,?,?,?)"
if(l[1]=='3'):
	statement="INSERT INTO MATCH VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
if(l[1]=='4'):
	statement="INSERT INTO PLAYER_MATCH VALUES (?,?,?,?,?,?,?)"
if(l[1]=='5'):
	statement="INSERT INTO BALL_BY_BALL VALUES (?,?,?,?,?,?,?,?,?,?,?)"
cursor.execute(statement, l[2:])
conn.commit()
conn.close()