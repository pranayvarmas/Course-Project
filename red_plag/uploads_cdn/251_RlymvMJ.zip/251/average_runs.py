import sqlite3
  
sample_dict = {} 
ans={}
conn = sqlite3.connect('ipl.db');
cursor = conn.cursor();
cursor.execute('SELECT * FROM MATCH')
for key in cursor:
    if key[6] not in sample_dict:
            sample_dict[key[6]] = list()
    sample_dict[key[6]].append(key[0])
for key in sample_dict:
    ans[key]=0
for key in sample_dict:
    for y in sample_dict[key]:
        cursor.execute("SELECT runs_scored, extra_runs FROM BALL_BY_BALL WHERE match_id=:Id", {"Id": y})
        for r in cursor:
            ans[key]+=r[0]+r[1]

for key in sample_dict:
    ans[key]=ans[key]*1.0/len(sample_dict[key])
 
    
for key, value in sorted(ans.items(), key=lambda item: item[1],reverse=True):
    print("%s,%s" % (key, value))

conn.rollback()