#include<bits/stdc++.h>
using namespace std;
void redistribute(int bags[],int k,int n,int m)
{
	while(bags[m]!=n)
	{
		int i=0;
		while(i<k)
		{
			if (i==m)
				i++;
			else {
				int num=bags[i];
				bags[i]=num/k;
				for (int j = 1; j < k; j++)	
					bags[(i+j) % k]+= (num/k);
				for (int j = 1; j <= (num%k); j++)
					bags[(i+j) % k]++;cout<<i<<" ";
				i++;
				}
	if (bags[m]==n) 
	return;
		}		
	}
}
int main()
{
	int n,k,m;
	cin>>n>>k;
	int bags[k];
	for (int i=0;i<k;i++){cin>>bags[i];}
	int* ax; 
	ax = std::max_element(bags,bags+k-1);
	m=ax-bags;
	redistribute(bags,k,n,m);
	cout<<m;
}