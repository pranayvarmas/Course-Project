#include<iostream>
#include<string>
using namespace std;
int main()
{
    string s;
    int k;
    cin>>s;
    cin>>k;
    int sum=0;
    for(int i=0;i<s.length()/k;i++)
    {
        int freq[26];
        for(int x=0;x<26;x++)
            freq[x]=0;
        for(int j=i;j<s.length();j=j+(s.length()/k))
        {
            freq[int(s[j])-97]++;
        }
        int maxx=freq[0];
        for(int x=0;x<26;x++)
            maxx=max(maxx,freq[x]);
        sum=sum+k-maxx;
    }
    cout<<sum<<endl;
  
}