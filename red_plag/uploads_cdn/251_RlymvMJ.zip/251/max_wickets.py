import sqlite3
conn = sqlite3.connect('ipl.db');
cursor = conn.cursor();
cursor.execute("DROP TABLE IF EXISTS RUNS")
conn.execute('''CREATE TABLE RUNS
       (id INTEGER PRIMARY KEY     NOT NULL,
       playername  TEXT NOT NULL,
        score  INTEGER  NOT NULL);''')

max_id=0
sum=0

cursor.execute('INSERT INTO RUNS SELECT player_id,player_name,0 FROM PLAYER')
cursor.execute('select * from RUNS order by id desc limit 1')
for x in cursor:
    max_id=x[0]
for x in range(1,max_id+1):
            sum=0
            cursor.execute("SELECT runs_scored FROM BALL_BY_BALL WHERE NOT out_type='Not Applicable' AND bowler=:Id", {"Id": x})
            for r in cursor:
                sum+=1
            cursor.execute("UPDATE  RUNS SET score=? WHERE id=?",(sum,x))

cursor.execute('select * from RUNS order by score desc,playername  limit 20')
for x in cursor:
    print(str(x[0])+","+x[1]+","+str(x[2]))
cursor.execute("DROP TABLE IF EXISTS RUNS")
conn.commit()
conn.close()