import sqlite3
conn = sqlite3.connect('ipl.db');
cursor = conn.cursor();
cursor.execute("DROP TABLE IF EXISTS HIT")
conn.execute('''CREATE TABLE HIT
       (id INTEGER PRIMARY KEY     NOT NULL,
       playername  TEXT NOT NULL,
       six  REAL  NOT NULL,
       balls    INTEGER NOT NULL,
       fractions REAL NOT NULL );''')

max_id=0
sum=0
six=0
l1=[]
cursor.execute('INSERT INTO HIT SELECT player_id,player_name,0,0,0 FROM PLAYER')
cursor.execute('select * from HIT order by id desc limit 1')
for x in cursor:
    max_id=x[0]
for x in range(1,max_id+1):
            total=0
            six=0
            cursor.execute("SELECT runs_scored FROM BALL_BY_BALL WHERE striker=:Id", {"Id": x})
            for r in cursor:
                total+=1
                if(r[0]==6):
                    six+=1
            if(total>0):
                fraction=six*1.0/total
                cursor.execute("UPDATE  HIT SET six=?,balls=?,fractions=?  WHERE id=?",(six,total,fraction,x))

cursor.execute('select * from HIT where balls > 0 order by fractions desc,playername')
for x in cursor:
    print(str(x[0])+","+x[1]+","+str(x[2])+","+str(x[3])+","+str(x[4]))
cursor.execute("DROP TABLE IF EXISTS HIT")
conn.rollback()