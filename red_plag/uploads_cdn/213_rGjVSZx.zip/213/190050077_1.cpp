#include<iostream>
using namespace std;
long long J(long long n,int k)
{ long long x;
    if(n==1)
        x=1;
    if(n!=1)
        x=((J(n-1,k)+k-1)%n)+1;

return x;
}
int main()
{
    long long n;
    int k;
    cin>>n>>k;
    cout<<J(n,k);
}