import sqlite3
conn = sqlite3.connect('ipl.db');
cursor = conn.cursor();
cursor.execute("DROP TABLE IF EXISTS TEAM")
conn.execute('''CREATE TABLE TEAM
       (team_id INTEGER PRIMARY KEY     NOT NULL,
        team_name  text  NOT NULL);''')
cursor.execute("DROP TABLE IF EXISTS MATCH")

conn.execute('''CREATE TABLE MATCH
        (match_id INTEGER PRIMARY KEY     NOT NULL,
        season_year     INTEGER  NOT NULL,
        team1           INTEGER  NOT NULL,
        team2           INTEGER  NOT NULL,
        battedfirst     INTEGER  NOT NULL,
        battedsecond    INTEGER  NOT NULL,  
        venue_name      TEXT     NOT NULL,
        city_name       TEXT     NOT NULL,
        country_name    TEXT     NOT NULL,
        toss_winner     TEXT     NOT NULL,
        match_winner    TEXT     NOT NULL,
        toss_name       TEXT     NOT NULL,
        win_type        INTEGER  NOT NULL,
        man_of_match      INTEGER  NOT NULL,
        win_margin  INTEGER  NOT NULL,
        FOREIGN KEY(team1)  REFERENCES TEAM (team_id),
        FOREIGN KEY(team2)  REFERENCES TEAM (team_id),
        FOREIGN KEY(battedfirst)  REFERENCES TEAM (team_id),
        FOREIGN KEY(battedsecond)  REFERENCES TEAM (team_id));''')
cursor.execute("DROP TABLE IF EXISTS PLAYER")

conn.execute('''CREATE TABLE PLAYER
       (player_id INTEGER PRIMARY KEY  NOT NULL,
        player_name     TEXT  NOT NULL,
        dob             TIMESTAMP,
        batting_hand    TEXT  NOT NULL,
        bowling_skill   TEXT  NOT NULL,
        country_name    TEXT  NOT NULL);''')

cursor.execute("DROP TABLE IF EXISTS PLAYER_MATCH")

conn.execute('''CREATE TABLE PLAYER_MATCH
       (playermatch_key INTEGER PRIMARY KEY  NOT NULL,
        match_id  INTEGER NOT NULL,
        player_id INTEGER NOT NULL,
        batting_hand  TEXT  NOT NULL,
        bowling_skill  TEXT  NOT NULL,
        role_desc  TEXT  NOT NULL,
        team_id  INTEGER NOT NULL,
       FOREIGN KEY(match_id)  REFERENCES MATCH (match_id),
        FOREIGN KEY(player_id)  REFERENCES PLAYER (player_id), 
      FOREIGN KEY(team_id)  REFERENCES TEAM (team_id));''')

cursor.execute("DROP TABLE IF EXISTS BALL_BY_BALL")

conn.execute('''CREATE TABLE BALL_BY_BALL
        (match_id INTEGER     NOT NULL,
        innings_no INTEGER   NOT NULL,
        overs_id INTEGER      NOT NULL,
        ball_id INTEGER      NOT NULL,
        striker_batting_position    INTEGER  NOT NULL,
        runs_scored           INTEGER           NOT NULL,
        extra_runs           INTEGER ,
        out_type           TEXT   ,
        striker              INTEGER  NOT NULL,
        non_striker            INTEGER  NOT NULL,
        bowler            INTEGER  NOT NULL,
        PRIMARY KEY(match_id,innings_no,overs_id,ball_id),
        FOREIGN KEY(match_id)  REFERENCES MATCH (match_id),
        FOREIGN KEY(striker)  REFERENCES PLAYER (player_id),
        FOREIGN KEY(non_striker)  REFERENCES PLAYER (player_id),
        FOREIGN KEY(bowler)  REFERENCES PLAYER (player_id));''')
conn.commit();
conn.close()