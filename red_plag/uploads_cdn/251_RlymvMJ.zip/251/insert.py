import csv
import sqlite3
conn = sqlite3.connect('ipl.db');
cursor = conn.cursor();

a_file = open("player.csv")
rows = csv.reader(a_file)
i=0
for row in rows:
    if(i!=0):
        cursor.execute("INSERT INTO PLAYER VALUES (?,?,?,?,?,?)", row)
    i=i+1;
a_file = open("match.csv")
rows = csv.reader(a_file)
i=0
for row in rows:
    if(i!=0):
        cursor.execute("INSERT INTO MATCH VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row)
    i=i+1;
a_file = open("team.csv")
rows = csv.reader(a_file)
i=0
for row in rows:
    if(i!=0):
        cursor.execute("INSERT INTO TEAM VALUES (?,?)", row)
    i=i+1;
a_file = open("player_match.csv")
rows = csv.reader(a_file)
i=0
for row in rows:
    if(i!=0):
        cursor.execute("INSERT INTO PLAYER_MATCH VALUES (?,?,?,?,?,?,?)", row)
    i=i+1;
a_file = open("ball_by_ball.csv")
rows = csv.reader(a_file)
i=0
for row in rows:
    if(i!=0):
        cursor.execute("INSERT INTO BALL_BY_BALL VALUES (?,?,?,?,?,?,?,?,?,?,?)", row)
    i=i+1;   


conn.commit();
conn.close();